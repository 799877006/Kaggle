CMAKE_MSVCIDE_RUN_PATH
----------------------

.. include:: ENV_VAR.txt

Extra PATH locations for custom commands when using
:ref:`Visual Studio Generators`.

The ``CMAKE_MSVCIDE_RUN_PATH`` environment variable sets the default value for
the :variable:`CMAKE_MSVCIDE_RUN_PATH` variable if not already explicitly set.
